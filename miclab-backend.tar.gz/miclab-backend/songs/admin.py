from django.contrib import admin
from .models import Song, Category, Favorite, UserProfile


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'slug', 'created_at']
    prepopulated_fields = {'slug': ('name',)}
    search_fields = ['name']


@admin.register(Song)
class SongAdmin(admin.ModelAdmin):
    list_display = ['title', 'artist', 'category', 'duration', 'is_active', 'created_at']
    list_filter = ['category', 'is_active', 'created_at']
    search_fields = ['title', 'artist']
    readonly_fields = ['created_at', 'updated_at']
    fieldsets = (
        ('Basic Info', {
            'fields': ('title', 'artist', 'category')
        }),
        ('Media', {
            'fields': ('audio_file', 'lyrics_file', 'thumbnail')
        }),
        ('Details', {
            'fields': ('duration', 'is_active')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )


@admin.register(Favorite)
class FavoriteAdmin(admin.ModelAdmin):
    list_display = ['user', 'song', 'added_at']
    list_filter = ['added_at']
    search_fields = ['user__email', 'song__title']
    readonly_fields = ['added_at']


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'subscription_type', 'trial_end_date', 'subscription_end_date']
    list_filter = ['subscription_type', 'trial_start_date']
    search_fields = ['user__email', 'user__username']
    readonly_fields = ['created_at', 'updated_at']

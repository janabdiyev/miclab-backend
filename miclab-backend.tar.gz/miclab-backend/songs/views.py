from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
from django.shortcuts import get_object_or_404
from django.db.models import Q
from .models import Song, Category, Favorite, UserProfile
from .serializers import (
    SongListSerializer, SongDetailSerializer,
    CategorySerializer, FavoriteSerializer,
    UserProfileSerializer
)


class CategoryViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [AllowAny]
    lookup_field = 'slug'


class SongViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Song.objects.filter(is_active=True)
    permission_classes = [AllowAny]

    def get_serializer_class(self):
        if self.action == 'retrieve':
            return SongDetailSerializer
        return SongListSerializer

    def get_serializer_context(self):
        context = super().get_serializer_context()
        context['request'] = self.request
        return context

    @action(detail=False, methods=['get'], permission_classes=[AllowAny])
    def search(self, request):
        query = request.query_params.get('q', '')
        if len(query) < 2:
            return Response({'detail': 'Query must be at least 2 characters'}, status=status.HTTP_400_BAD_REQUEST)

        songs = Song.objects.filter(
            Q(title__icontains=query) | Q(artist__icontains=query),
            is_active=True
        )
        serializer = SongListSerializer(
            songs, many=True,
            context={'request': request}
        )
        return Response(serializer.data)

    @action(detail=False, methods=['get'], permission_classes=[AllowAny])
    def by_category(self, request):
        category_slug = request.query_params.get('category')
        if not category_slug:
            return Response(
                {'detail': 'Category slug required'},
                status=status.HTTP_400_BAD_REQUEST
            )

        category = get_object_or_404(Category, slug=category_slug)
        songs = Song.objects.filter(category=category, is_active=True)
        serializer = SongListSerializer(
            songs, many=True,
            context={'request': request}
        )
        return Response(serializer.data)


class FavoriteViewSet(viewsets.ModelViewSet):
    serializer_class = FavoriteSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Favorite.objects.filter(user=self.request.user)

    def perform_create(self, serializer):
        song_id = self.request.data.get('song_id')
        song = get_object_or_404(Song, id=song_id)
        serializer.save(user=self.request.user, song=song)

    @action(detail=False, methods=['post'])
    def toggle(self, request):
        song_id = request.data.get('song_id')
        song = get_object_or_404(Song, id=song_id)

        favorite = Favorite.objects.filter(user=request.user, song=song).first()
        if favorite:
            favorite.delete()
            return Response({'detail': 'Removed from favorites'}, status=status.HTTP_204_NO_CONTENT)
        else:
            Favorite.objects.create(user=request.user, song=song)
            return Response({'detail': 'Added to favorites'}, status=status.HTTP_201_CREATED)


class UserProfileViewSet(viewsets.ViewSet):
    permission_classes = [IsAuthenticated]

    @action(detail=False, methods=['get'])
    def my_profile(self, request):
        profile = get_object_or_404(UserProfile, user=request.user)
        serializer = UserProfileSerializer(profile)
        return Response(serializer.data)
